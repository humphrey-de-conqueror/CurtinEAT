package com.example.curtineat.data.local.room.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
	tableName = "products",
	indices = [
		Index(value = ["vendorId"])
	]
)
data class ProductEntity(
	@PrimaryKey
	val productId: String,

	val vendorId: String,
	val productName: String,
	val productPrice: Double,

	// Image API identifier.
	val productImage: String,

	val isAvailable: Boolean
)