package com.example.curtineat.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun AppText(
	text: String,
	modifier: Modifier = Modifier,
	style: TextStyle = MaterialTheme.typography.bodyLarge,
	color: Color = MaterialTheme.colorScheme.onSurface,
	fontWeight: FontWeight? = null,
	textAlign: TextAlign? = null,
	maxLines: Int = Int.MAX_VALUE,
	overflow: TextOverflow = TextOverflow.Clip
) {
	Text(
		text = text,
		modifier = modifier,
		style = style,
		color = color,
		fontWeight = fontWeight,
		textAlign = textAlign,
		maxLines = maxLines,
		overflow = overflow
	)
}